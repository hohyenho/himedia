##깃허브에 처음 데이터를 올리는 명령어

git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/hohyenho/himedia.git
git push -u origin main